document.getElementById("ctaButton").addEventListener("click", function() {
  window.location.href = "https://www.arlink.io";  // Redirect to ARlink's website or any other page
});
